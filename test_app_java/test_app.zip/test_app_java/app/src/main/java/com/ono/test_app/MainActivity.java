package com.ono.test_app;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;

public class MainActivity extends AppCompatActivity {

    private String test = MyApplication.pref.get("0", "");

    @Override
    protected void onCreate(Bundle bundle) {
        encryption();
        super.onCreate(bundle);
        this.setContentView(R.layout.activity_main);
        TextView textView = findViewById(R.id.textView);
        textView.setText(test);
        fTest(MyApplication.pref.get("1", ""));
    }

    void fTest(String test) {
        test = MyApplication.pref.get("2", "");
        String t = MyApplication.pref.get("3", "");
    }

    private void encryption() {
        SharedPreferences pref = this.getPreferences(Context.MODE_PRIVATE);
        SecureSharedPreferences securePref = new SecureSharedPreferences(pref);
        loadJSONFromAsset(this);
        try {
            JSONObject jsonObject = new JSONObject(loadJSONFromAsset(this));
            Iterator<String> keys = jsonObject.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                MyApplication.pref.put(key, jsonObject.get(key).toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String loadJSONFromAsset(Context context) {
        String json = null;
        try {
            InputStream is = context.getAssets().open("encryption.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return json;
    }
}
