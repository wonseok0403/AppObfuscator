package com.ono.test_app;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import org.json.JSONObject;

import java.io.InputStream;
import java.util.Iterator;

public class MyApplication extends Application {

    static SecureSharedPreferences pref = null;
    
    private void encryption() {
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
        SecureSharedPreferences securePref = new SecureSharedPreferences(pref);
        loadJSONFromAsset(this);
        try {
            JSONObject jsonObject = new JSONObject(loadJSONFromAsset(this));
            Iterator<String> keys = jsonObject.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                MyApplication.pref.put(key, jsonObject.get(key).toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String loadJSONFromAsset(Context context) {
        String json = null;
        try {
            InputStream is = context.getAssets().open("encryption.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return json;
    }
}
